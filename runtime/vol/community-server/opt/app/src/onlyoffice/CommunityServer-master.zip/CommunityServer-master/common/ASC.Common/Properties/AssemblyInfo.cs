using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ASC.Common")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Ascensio System SIA")]
[assembly: AssemblyProduct("ASC.Common")]
[assembly: AssemblyCopyright("(c) Ascensio System SIA. All rights reserved")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("dfaa902e-d55c-477a-b101-8b8a37d7df30")]
[assembly: AssemblyVersion("1.0.0.0")]
