using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ASC.Core.Common")]
[assembly: AssemblyCompany("Ascensio System SIA")]
[assembly: AssemblyProduct("ASC.Core.Common")]
[assembly: AssemblyCopyright("(c) Ascensio System SIA. All rights reserved")]
[assembly: ComVisible(false)]
[assembly: Guid("3ff04204-4b22-4899-bcde-07edfcbb5355")]
[assembly: AssemblyVersion("1.0.0.0")]
