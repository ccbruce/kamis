<?php

return [
    'Names' => [
        'DJF' => [
            0 => 'Fdj',
            1 => 'فرنك جيبوتي',
        ],
    ],
];
