<?php

return [
    'Names' => [
        'BAM' => [
            0 => 'KM',
            1 => 'Bosanskohercegovačka konvertibilna marka',
        ],
        'BYN' => [
            0 => 'BYN',
            1 => 'Bjeloruska rublja',
        ],
        'KPW' => [
            0 => 'KPW',
            1 => 'Sjevernokorejski von',
        ],
        'NIO' => [
            0 => 'NIO',
            1 => 'Nikaragvanska zlatna kordoba',
        ],
    ],
];
