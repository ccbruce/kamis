<?php

return [
    'Names' => [
        'PAB' => [
            0 => 'B/.',
            1 => 'balboa panameño',
        ],
    ],
];
