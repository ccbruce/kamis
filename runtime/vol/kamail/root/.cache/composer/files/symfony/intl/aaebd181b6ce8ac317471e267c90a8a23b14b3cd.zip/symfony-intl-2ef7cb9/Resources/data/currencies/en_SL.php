<?php

return [
    'Names' => [
        'SLL' => [
            0 => 'Le',
            1 => 'Sierra Leonean Leone',
        ],
    ],
];
