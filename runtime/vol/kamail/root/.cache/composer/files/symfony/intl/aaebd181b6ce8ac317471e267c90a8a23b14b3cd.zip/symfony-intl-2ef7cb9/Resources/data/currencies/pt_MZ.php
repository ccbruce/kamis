<?php

return [
    'Names' => [
        'MZN' => [
            0 => 'MTn',
            1 => 'metical moçambicano',
        ],
    ],
];
