<?php

return [
    'Names' => [
        'GYD' => [
            0 => '$',
            1 => 'Guyanaese Dollar',
        ],
    ],
];
