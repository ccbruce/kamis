<?php

return [
    'Names' => [
        'DJF' => [
            0 => 'Fdj',
            1 => 'Faran Jabuuti',
        ],
    ],
];
