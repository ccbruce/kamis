<?php

return [
    'Names' => [
        'FKP' => [
            0 => '£',
            1 => 'Falkland Islands Pound',
        ],
        'GBP' => [
            0 => 'GB£',
            1 => 'British Pound',
        ],
    ],
];
