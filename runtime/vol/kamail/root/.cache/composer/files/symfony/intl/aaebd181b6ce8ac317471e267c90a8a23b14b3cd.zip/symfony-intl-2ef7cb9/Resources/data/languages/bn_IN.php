<?php

return [
    'Names' => [
        'ksh' => 'কোলোনিয়ান',
    ],
    'LocalizedNames' => [
    ],
];
