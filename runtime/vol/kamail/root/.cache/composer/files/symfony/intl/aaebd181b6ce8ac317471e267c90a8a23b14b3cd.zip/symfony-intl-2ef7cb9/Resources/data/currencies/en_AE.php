<?php

return [
    'Names' => [
        'AED' => [
            0 => 'AED',
            1 => 'United Arab Emirates Dirham',
        ],
    ],
];
