import { RedisOptions } from 'ioredis';

export type { RedisOptions };
