# AFFiNE Command Abstractions

This package contains the command abstractions for the AFFiNE framework to be used for CMD-K.

The implementation is highly inspired by the [VSCode Command Abstractions](https://github.com/microsoft/vscode)
