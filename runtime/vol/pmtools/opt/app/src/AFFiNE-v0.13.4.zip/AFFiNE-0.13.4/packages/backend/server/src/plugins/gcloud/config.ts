export interface GCloudConfig {}
