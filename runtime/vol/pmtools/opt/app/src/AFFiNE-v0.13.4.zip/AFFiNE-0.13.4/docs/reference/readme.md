Welcome to AFFiNE development reference.

This document is intended for developers who want to contribute to AFFiNE. It contains information about the architecture of AFFiNE, how to build it, and how to contribute to it.

### The Infrastructure of AFFiNE

see {@link @toeverything/infra!}
