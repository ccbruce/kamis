# Contributor Add

- https://allcontributors.org/docs/en/cli/usage
- https://allcontributors.org/docs/en/emoji-key

```shell
all-contributors check
all-contributors add tzhangchi code,doc
all-contributors generate
```
