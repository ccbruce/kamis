import { createScope } from '../di';

export const WorkspaceScope = createScope('workspace');
