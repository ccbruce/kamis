-- AlterTable
ALTER TABLE "users" ADD COLUMN     "registered" BOOLEAN NOT NULL DEFAULT true;
