-- AlterTable
ALTER TABLE "user_invoices" ADD COLUMN     "link" TEXT;
