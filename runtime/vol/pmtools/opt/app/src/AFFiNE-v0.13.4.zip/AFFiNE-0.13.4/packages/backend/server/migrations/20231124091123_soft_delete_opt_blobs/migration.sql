-- AlterTable
ALTER TABLE "optimized_blobs" ADD COLUMN     "deleted_at" TIMESTAMPTZ(6);
