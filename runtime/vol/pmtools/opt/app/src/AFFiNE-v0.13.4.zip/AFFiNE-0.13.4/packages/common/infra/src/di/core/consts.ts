import type { ServiceVariant } from './types';

export const DEFAULT_SERVICE_VARIANT: ServiceVariant = 'default';
export const ROOT_SCOPE = [];
