export const gql = '/graphql';
