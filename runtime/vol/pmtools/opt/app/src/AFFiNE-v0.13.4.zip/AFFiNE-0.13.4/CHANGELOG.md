# Changelog

See the [AFFiNE CHANGELOG](https://affine.pro/blog?tag=Release%20Note)

---
