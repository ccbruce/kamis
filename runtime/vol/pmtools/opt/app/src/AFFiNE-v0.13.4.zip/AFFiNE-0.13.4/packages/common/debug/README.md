# @affine/debug

A common debug interface for packages in this repository.
