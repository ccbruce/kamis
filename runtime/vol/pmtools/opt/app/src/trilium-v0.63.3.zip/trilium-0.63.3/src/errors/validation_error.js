class ValidationError {
    constructor(message) {
        this.message = message;
    }
}

module.exports = ValidationError;