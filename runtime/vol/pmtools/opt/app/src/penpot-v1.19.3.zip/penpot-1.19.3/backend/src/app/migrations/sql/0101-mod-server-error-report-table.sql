ALTER TABLE server_error_report
 ADD COLUMN version integer DEFAULT 1;
