DROP TABLE file_share_token;
