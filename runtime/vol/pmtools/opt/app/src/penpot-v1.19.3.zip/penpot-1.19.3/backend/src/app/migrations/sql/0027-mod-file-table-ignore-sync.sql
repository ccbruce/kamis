ALTER TABLE file 
  ADD COLUMN ignore_sync_until timestamptz NULL;

