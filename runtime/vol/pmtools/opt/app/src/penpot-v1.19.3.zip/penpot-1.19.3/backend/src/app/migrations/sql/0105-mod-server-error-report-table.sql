CREATE INDEX server_error_report__created_at__idx
    ON server_error_report ( created_at );
