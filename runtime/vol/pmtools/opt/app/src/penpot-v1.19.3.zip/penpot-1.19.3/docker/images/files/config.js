// Frontend configuration
//var penpotFlags = "";
