CREATE INDEX file_change__created_at_idx
    ON file_change (created_at);
