#!/usr/bin/env bash

set -ex

export PATH="/usr/local/nodejs/bin/:$PATH"

exec "$@"
