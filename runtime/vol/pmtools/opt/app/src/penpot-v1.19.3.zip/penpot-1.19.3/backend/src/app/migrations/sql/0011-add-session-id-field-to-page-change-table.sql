ALTER TABLE page_change
  ADD COLUMN session_id uuid DEFAULT NULL;
