DROP TABLE file_frame_thumbnail;
