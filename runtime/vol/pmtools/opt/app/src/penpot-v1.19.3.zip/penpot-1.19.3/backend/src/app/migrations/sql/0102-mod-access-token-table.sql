ALTER TABLE access_token
 ADD COLUMN expires_at timestamptz NULL;
