ALTER TABLE comment_thread
  ADD COLUMN page_name text NULL;
