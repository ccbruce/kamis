ALTER TABLE audit_log
  ADD COLUMN ip_addr inet NULL;
