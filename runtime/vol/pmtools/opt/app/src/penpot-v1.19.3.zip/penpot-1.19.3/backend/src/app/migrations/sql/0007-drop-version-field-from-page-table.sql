ALTER TABLE page
  DROP COLUMN version;
