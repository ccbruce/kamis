DROP TABLE generic_token;
