DROP TABLE profile_attr;
