DROP FUNCTION update_modified_at () CASCADE;
DROP FUNCTION handle_delete ( ) CASCADE;
DROP TABLE pending_to_delete;
