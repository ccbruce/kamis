ALTER TABLE profile
  ADD COLUMN is_blocked boolean DEFAULT false;
