ALTER TABLE file
  ADD COLUMN features text[] DEFAULT NULL;
