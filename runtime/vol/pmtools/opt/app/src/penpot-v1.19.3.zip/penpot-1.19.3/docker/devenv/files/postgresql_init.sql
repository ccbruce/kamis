CREATE DATABASE penpot_test;
CREATE DATABASE penpot_telemetry;
