DROP TABLE storage_data;
