DROP TABLE storage_pending;
