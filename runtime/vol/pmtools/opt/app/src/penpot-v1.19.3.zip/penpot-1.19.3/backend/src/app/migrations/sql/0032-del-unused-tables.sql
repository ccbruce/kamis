DROP TABLE color;
DROP TABLE page_change;
DROP TABLE page_version;
