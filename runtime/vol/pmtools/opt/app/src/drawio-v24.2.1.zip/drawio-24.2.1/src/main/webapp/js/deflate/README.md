# Updating (with IE 11 compatibility)

Copy https://github.com/nodeca/pako/blob/master/dist/pako.es5.min.js to
src/main/webapp/js/deflate/pako.min.js in this repository
