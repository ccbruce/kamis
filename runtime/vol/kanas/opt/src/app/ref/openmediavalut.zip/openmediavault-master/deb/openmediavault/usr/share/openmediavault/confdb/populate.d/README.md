Put your scripts here that should be executed to read/parse/extract information from the system into the database.
The scripts are executed once after the openmediavault Debian package has been installed on the system.
