Put your configuration database migration shell scripts here. The files must
look like:

<DATAMODELID>_<VERSION>[.<EXT>]

Example:
conf.service.clamav_0.5.3
conf.service.clamav_1.5.0.1.sh
