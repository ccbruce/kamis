# Disable fancy (the colored [ OK ] [FAIL] etc) log messages.
FANCYTTY=0
