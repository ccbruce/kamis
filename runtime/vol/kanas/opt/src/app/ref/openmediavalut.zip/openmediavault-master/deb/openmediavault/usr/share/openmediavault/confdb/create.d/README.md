Put your configuration database creation shell scripts here. The files must
look like:

<DATAMODELID>[.<EXT>]

Example:
conf.service.clamav
conf.service.clamav.sh
