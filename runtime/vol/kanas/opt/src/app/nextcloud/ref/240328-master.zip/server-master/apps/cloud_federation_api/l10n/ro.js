OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "API-ul Cloud Federation",
    "Enable clouds to communicate with each other and exchange data" : "Permiteți serviciilor de cloud să comunice între ele și să facă schimb de date",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "API-ul Cloud Federation permite diferitelor instanțe Nextcloud să comunice între ele și să facă schimb de date."
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");
