OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Sledenje / Beleženje",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Omogoča beleženje dejanj v okolju Nextcloud, kot so dostopi do datotek in druga podobna dejanja."
},
"nplurals=4; plural=(n%100==1 ? 0 : n%100==2 ? 1 : n%100==3 || n%100==4 ? 2 : 3);");
