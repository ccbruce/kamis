OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Cloud Federation API",
    "Enable clouds to communicate with each other and exchange data" : "Erlaubt es, dass Server miteinander kommunizieren und Daten austauschen",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "Die Cloud Federation API ermöglicht es Nextcloud-Instanzen miteinander zu kommunizieren und Daten auszutauschen."
},
"nplurals=2; plural=(n != 1);");
