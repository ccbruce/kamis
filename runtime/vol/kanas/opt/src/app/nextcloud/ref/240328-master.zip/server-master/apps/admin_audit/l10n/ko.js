OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "검사 / 로깅",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Nextcloud에게 로그 파일 접근 혹은 기타 민감한 작업과 같은 로깅 권한을 부여합니다."
},
"nplurals=1; plural=0;");
