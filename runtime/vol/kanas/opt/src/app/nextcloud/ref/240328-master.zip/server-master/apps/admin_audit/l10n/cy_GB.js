OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Archwilio / Cofnodi",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Yn darparu galluoedd cofnodi ar gyfer Nextcloud megis cofnodi mynediadau ffeiliau neu gamau gweithredu sensitif."
},
"nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;");
