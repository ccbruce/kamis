OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "واجهة برمجة التطبيقات API للاتحاد السحابي Cloud Federation",
    "Enable clouds to communicate with each other and exchange data" : "يسمح للسحابات أن تتراسل فيما بينها و تتبادل البيانات",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "واجهة برمجة التطبيقات API للاتحاد السحابي Cloud Federation تسمح لخوادم نكست كلاود بالاتصال ببعضها البعض و تبادل البيانات."
},
"nplurals=6; plural=n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5;");
