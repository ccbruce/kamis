OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Աուդիտ / Տեղեկագրում",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Nextcloud ֊ի համար տրամադրում է տեղեկագրման հնարավորություն՝ նիշքերի հասանելիության և զգայուն գործողություինների պահպանումը տեղեկամատյանում։"
},
"nplurals=2; plural=(n != 1);");
