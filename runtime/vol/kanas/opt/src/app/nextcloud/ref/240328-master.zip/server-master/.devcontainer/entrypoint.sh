#!/bin/bash

sudo service apache2 start

while sleep 1000; do :; done
