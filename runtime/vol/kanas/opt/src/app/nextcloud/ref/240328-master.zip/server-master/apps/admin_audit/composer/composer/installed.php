<?php return array(
    'root' => array(
        'name' => '__root__',
        'pretty_version' => 'dev-master',
        'version' => 'dev-master',
        'reference' => 'b1797842784b250fb01ed5e3bf130705eb94751b',
        'type' => 'library',
        'install_path' => __DIR__ . '/../',
        'aliases' => array(),
        'dev' => false,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => 'dev-master',
            'version' => 'dev-master',
            'reference' => 'b1797842784b250fb01ed5e3bf130705eb94751b',
            'type' => 'library',
            'install_path' => __DIR__ . '/../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
