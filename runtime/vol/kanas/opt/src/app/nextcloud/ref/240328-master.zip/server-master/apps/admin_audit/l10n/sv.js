OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Granskning / Loggning",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Tillhandahåller loggningsmöjligheter för Nextcloud, så som filåtkomster eller andra känsliga händelser"
},
"nplurals=2; plural=(n != 1);");
