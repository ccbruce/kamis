OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "API de Nuvem Federada",
    "Enable clouds to communicate with each other and exchange data" : "Permite que diferentes nuvens se comuniquem entre si e troquem dados",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "A API de Nuvem Federada permite que várias instâncias do Nextcloud se comuniquem entre si e troquem dados."
},
"nplurals=3; plural=(n == 0 || n == 1) ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
