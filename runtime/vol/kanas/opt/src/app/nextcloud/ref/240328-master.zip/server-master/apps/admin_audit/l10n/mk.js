OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Ревизија / Евиденција",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Обезбедува можности за евидентирање на Nextcloud, како што се евидентирање пристапи до датотеки или на друг начин чувствителни дејства."
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
