OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Vmesnik API zveznega oblaka",
    "Enable clouds to communicate with each other and exchange data" : "Omogoči povezovanje različnih oblakov in varno izmenjavo podatkov",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "Vmesnik API zveznega oblaka omogoča povezovanje različnih okolij Nextcloud na različnih strežnikih za varno izmenjavo podatkov."
},
"nplurals=4; plural=(n%100==1 ? 0 : n%100==2 ? 1 : n%100==3 || n%100==4 ? 2 : 3);");
