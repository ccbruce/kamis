OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "API-forritsviðmót fyrir skýjasambandsveitur",
    "Enable clouds to communicate with each other and exchange data" : "Gerir gagnaskýjum kleift að hafa samskipti við hvert annað og skiptast á gögnum",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "API-forritsviðmót fyrir skýjasambandsveitur (Cloud Federation API) gerir Nextcloud-gagnaskýjum kleift að hafa samskipti við hvert annað og skiptast á gögnum."
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
