OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditare / Logare",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Oferă abilități de înregistrare pentru Nextcloud, cum ar fi înregistrarea accesării fișierelor sau alte acțiuni sensibile."
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");
