OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Audit / Giriş",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Nextcloud üçün fayl girişləri və ya başqa həssas hərəkətlər kimi giriş imkanlarını təmin edir."
},
"nplurals=2; plural=(n != 1);");
