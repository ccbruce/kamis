OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "API فدراسیون ابری",
    "Enable clouds to communicate with each other and exchange data" : "ابرها را فعال کنید تا با یکدیگر ارتباط برقرار کنند و داده ها را مبادله کنند",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "Cloud Federation API نمونه های مختلف Nextcloud را قادر می سازد تا با یکدیگر ارتباط برقرار کرده و داده ها را مبادله کنند."
},
"nplurals=2; plural=(n > 1);");
