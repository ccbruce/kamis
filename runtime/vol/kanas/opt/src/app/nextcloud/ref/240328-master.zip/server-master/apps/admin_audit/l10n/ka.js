OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "აუდიტი / ჟურნალი",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "იძლევა ჟურნალის შესაძლებლობებს Nextcloud-ისთვის, როგორიცაა ფაილებზე წვდომის ან სხვა მგრძნობიარე ქმედებების ჩაწერა."
},
"nplurals=2; plural=(n!=1);");
