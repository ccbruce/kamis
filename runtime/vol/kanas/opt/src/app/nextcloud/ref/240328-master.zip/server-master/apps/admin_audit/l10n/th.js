OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "การตรวจสอบ / บันทึก",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "ให้ความสามารถในการบันทึก (logging) สำหรับ Nextcloud เช่น การบันทึกการเข้าถึงไฟล์ หรือการดำเนินการที่ละเอียดอ่อน"
},
"nplurals=1; plural=0;");
