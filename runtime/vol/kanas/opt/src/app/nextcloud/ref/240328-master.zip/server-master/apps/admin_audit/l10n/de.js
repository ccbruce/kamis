OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditieren/Protokollieren",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Stellt Protokollierungsfunktionen für Nextcloud zur Verfügung wie Dateizugriffe oder andere vertrauliche Aktionen."
},
"nplurals=2; plural=(n != 1);");
