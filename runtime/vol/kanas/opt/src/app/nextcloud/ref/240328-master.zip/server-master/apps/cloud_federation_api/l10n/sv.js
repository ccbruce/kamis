OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Moln-federations API",
    "Enable clouds to communicate with each other and exchange data" : "Tillåter olika moln att kommunicera med varandra samt utbyta data",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "Moln-federations API:et tillåter olika Nextcloud-instanser att kommunicera med varandra samt utbyta data."
},
"nplurals=2; plural=(n != 1);");
