OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "API de la federación na nube",
    "Enable clouds to communicate with each other and exchange data" : "Permite que les nubes se comuniquen ente elles ya intercambien datos",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "L'API de la federación na nube permite que delles instancies de Nextcloud se comuniquen ente elles ya intercambien datos."
},
"nplurals=2; plural=(n != 1);");
