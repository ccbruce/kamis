OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "API Chmury Federacyjnej",
    "Enable clouds to communicate with each other and exchange data" : "Umożliwia chmurom komunikację między sobą i wymianę danych",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "API Chmury Federacyjnej umożliwia różnym instancjom Nextcloud komunikowanie się ze sobą i wymianę danych."
},
"nplurals=4; plural=(n==1 ? 0 : (n%10>=2 && n%10<=4) && (n%100<12 || n%100>14) ? 1 : n!=1 && (n%10>=0 && n%10<=1) || (n%10>=5 && n%10<=9) || (n%100>=12 && n%100<=14) ? 2 : 3);");
