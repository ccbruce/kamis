OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Cloud Federation API",
    "Enable clouds to communicate with each other and exchange data" : "Cho phép các đám mây giao tiếp với nhau và trao đổi dữ liệu",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "API Cloud Federation cho phép các phiên bản Nextcloud khác nhau giao tiếp với nhau và trao đổi dữ liệu."
},
"nplurals=1; plural=0;");
