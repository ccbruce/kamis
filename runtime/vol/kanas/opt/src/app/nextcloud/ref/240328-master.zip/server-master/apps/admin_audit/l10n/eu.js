OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditoretza / Erregistroa",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Nextcloudi  gaitasuna ematen dio, adibidez, saio-hasiera fitxategiak atzitzeko edo beste kontuzko ekintza batzuetarako."
},
"nplurals=2; plural=(n != 1);");
