OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "حسابرسی / ورود به سیستم",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "قابلیت‌های ثبت‌نام را برای نکست‌کلود فراهم می‌کند، مانند ثبت دسترسی به فایل‌ها یا اقدامات حساس دیگر."
},
"nplurals=2; plural=(n > 1);");
