OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Cloud Federation API",
    "Enable clouds to communicate with each other and exchange data" : "Gør det muligt for skyer at kommunikere med hinanden og udveksle data",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "Cloud Federation API gør det muligt for forskellige Nextcloud-instanser at kommunikere med hinanden og udveksle data."
},
"nplurals=2; plural=(n != 1);");
