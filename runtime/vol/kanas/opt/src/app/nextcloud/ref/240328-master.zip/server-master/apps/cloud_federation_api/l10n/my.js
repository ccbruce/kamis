OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Cloud ဖွဲ့စည်းမှု API ",
    "Enable clouds to communicate with each other and exchange data" : "Cloud များကို တစ်ခုခုနှင့်တစ်ခု ဆက်သွယ်ခြင်း၊ သတင်းအချက်အလက်ဖလှယ်ခြင်းကို ပြုလုပ်နိုင်ရန် ဖွင့်ပေးပါ။"
},
"nplurals=1; plural=0;");
