OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "API da Nube federada",
    "Enable clouds to communicate with each other and exchange data" : "Permite que as nubes se comuniquen entre elas e intercambien datos",
    "The Cloud Federation API enables various Nextcloud instances to communicate with each other and to exchange data." : "A API de Nube federada permite que varias instancias de Nextcloud se comuniquen entre elas e intercambien datos."
},
"nplurals=2; plural=(n != 1);");
