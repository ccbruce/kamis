OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "‎Kiểm tra / Nhật ký‎",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "‎Cung cấp khả năng ghi nhật ký cho Nextcloud, chẳng hạn như ghi nhật ký quyền truy cập tệp hoặc các hành động nhạy cảm khác.‎"
},
"nplurals=1; plural=0;");
