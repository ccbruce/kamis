OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "פיקוח / תיעוד",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "מספק יכולות תיעוד ל־Nextcloud כגון תיעוד גישה ליומן התיעוד או פעולות רגישות אחרות."
},
"nplurals=3; plural=(n == 1 && n % 1 == 0) ? 0 : (n == 2 && n % 1 == 0) ? 1: 2;");
