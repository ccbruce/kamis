OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Auditoría / Rexistro",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Fornece recursos de rexistro para Nextcloud como rexistros de acceso a ficheiros ou calquera outra acción sensíbel."
},
"nplurals=2; plural=(n != 1);");
