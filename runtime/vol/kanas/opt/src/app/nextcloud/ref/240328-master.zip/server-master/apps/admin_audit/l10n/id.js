OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Pemeriksaan / Pencatatan",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Menyediakan kemampuan pencatatan untuk Nextcloud seperti pencatatan akses berkas atau tindakan sensitif lainnya."
},
"nplurals=1; plural=0;");
