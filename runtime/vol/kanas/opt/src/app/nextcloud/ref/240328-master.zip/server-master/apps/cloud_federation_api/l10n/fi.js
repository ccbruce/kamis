OC.L10N.register(
    "cloud_federation_api",
    {
    "Cloud Federation API" : "Pilvifederaation rajapinta",
    "Enable clouds to communicate with each other and exchange data" : "Mahdollistaa pilvien viestiä ja vaihtaa dataa toistensa kanssa"
},
"nplurals=2; plural=(n != 1);");
