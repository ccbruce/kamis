OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Eftirlit / Atvikaskráning",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Býður upp á atvikaskráningu fyrir Nextcloud, eins og að skrá aðgang að skrám og fleiri viðkvæmar aðgerðir."
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
