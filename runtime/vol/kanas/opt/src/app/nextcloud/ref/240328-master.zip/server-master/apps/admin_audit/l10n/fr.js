OC.L10N.register(
    "admin_audit",
    {
    "Auditing / Logging" : "Audit / Journalisation",
    "Provides logging abilities for Nextcloud such as logging file accesses or otherwise sensitive actions." : "Fournit des capacités de journalisation pour Nextcloud, telles que la journalisation des accès aux fichiers ou d’autres actions sensibles."
},
"nplurals=3; plural=(n == 0 || n == 1) ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
