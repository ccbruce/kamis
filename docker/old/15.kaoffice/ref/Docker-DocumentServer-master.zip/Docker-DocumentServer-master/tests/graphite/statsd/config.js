{
  "graphiteHost": "onlyoffice-graphite",
  "graphitePort": 2003,
  "port": 8125,
  "flushInterval": 60000,
  "backends": [ "./backends/graphite.js" ]
}
