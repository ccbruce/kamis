import logging

from scale_build.main import main

logger = logging.getLogger(__name__)


if __name__ == "__main__":
    main()
