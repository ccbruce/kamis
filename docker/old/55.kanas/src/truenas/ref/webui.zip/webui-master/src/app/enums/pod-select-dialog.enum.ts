export enum PodSelectDialogType {
  Logs = 'LOGS',
  Shell = 'SHELL',
}
