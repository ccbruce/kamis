export enum DiskWipeMethod {
  Quick = 'QUICK',
  Full = 'FULL',
  FullRandom = 'FULL_RANDOM',
}
