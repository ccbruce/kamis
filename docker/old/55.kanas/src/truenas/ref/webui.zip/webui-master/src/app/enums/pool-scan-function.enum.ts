export enum PoolScanFunction {
  Scrub = 'SCRUB',
  Resilver = 'RESILVER',
}
