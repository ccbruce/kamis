export enum ChartSchemaType {
  Int = 'int',
  String = 'string',
  Boolean = 'boolean',
  Hostpath = 'hostpath',
  Path = 'path',
  List = 'list',
  Dict = 'dict',
  Ipaddr = 'ipaddr',
  Cron = 'cron',
  Uri = 'uri',
}
