export enum TrueCommandStatus {
  Disabled = 'DISABLED',
  Connecting = 'CONNECTING',
  Connected = 'CONNECTED',
  Failed = 'FAILED',
}
