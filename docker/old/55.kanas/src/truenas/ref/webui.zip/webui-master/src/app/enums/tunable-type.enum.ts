export enum TunableType {
  Sysctl = 'SYSCTL',
}
