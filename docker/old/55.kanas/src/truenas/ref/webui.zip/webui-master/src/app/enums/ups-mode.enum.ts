export enum UpsMode {
  Master = 'MASTER',
  Slave = 'SLAVE',
}

export enum UpsShutdownMode {
  LowBattery = 'LOWBATT',
  Battery = 'BATT',
}
