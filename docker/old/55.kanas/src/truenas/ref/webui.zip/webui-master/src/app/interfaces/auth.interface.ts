export type LoginQuery = [
  username: string,
  password: string,
  otp?: string,
];
