export enum ProductEnclosure {
  Tower = 'tower',
  Rackmount = 'rackmount',
}
