export enum NfsSecurityProvider {
  Sys = 'SYS',
  Krb5 = 'KRB5',
  Krb5i = 'KRB5I',
  Krb5p = 'KRB5P',
}
