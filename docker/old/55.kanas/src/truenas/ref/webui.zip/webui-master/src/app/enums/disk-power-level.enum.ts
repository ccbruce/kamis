export enum DiskPowerLevel {
  Disabled = 'DISABLED',
  Level1 = '1',
  Level64 = '64',
  Level127 = '127',
  Level128 = '128',
  Level192 = '192',
  Level254 = '254',
}
