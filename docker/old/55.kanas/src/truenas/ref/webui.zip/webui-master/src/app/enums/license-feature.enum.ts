export enum LicenseFeature {
  Jails = 'JAILS', // Jails are used for apps as well
  FibreChannel = 'FIBRECHANNEL',
  Dedup = 'DEDUP',
  Vm = 'VM',
}
