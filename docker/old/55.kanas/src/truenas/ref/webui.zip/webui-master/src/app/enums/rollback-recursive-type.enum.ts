export enum RollbackRecursiveType {
  Recursive = 'recursive',
  RecursiveClones = 'recursive_clones',
}
