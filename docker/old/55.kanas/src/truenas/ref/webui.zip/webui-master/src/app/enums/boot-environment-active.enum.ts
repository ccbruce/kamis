export enum BootEnvironmentActive {
  Now = 'N',
  Reboot = 'R',
  NowReboot = 'NR',
  Dash = '-',
  Empty = '',
}
