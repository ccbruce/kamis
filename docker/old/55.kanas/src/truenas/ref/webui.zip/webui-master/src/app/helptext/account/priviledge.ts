import { marker as T } from '@biesbjerg/ngx-translate-extract-marker';

export const helptextPrivilege = {
  minimalRolesTooltip: T('Only Readonly Admin, Sharing Admin or Full Admin roles are supported in WebUI.'),
};
