export enum DiskType {
  Hdd = 'HDD',
  Ssd = 'SSD',
}
