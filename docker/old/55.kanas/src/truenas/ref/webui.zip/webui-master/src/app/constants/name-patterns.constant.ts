export const patterns = {
  targetDeviceName: /^[a-z0-9\\.\-:]+$/,
};
