export enum DirectoryServiceState {
  Disabled = 'DISABLED',
  Healthy = 'HEALTHY',
  Faulted = 'FAULTED',
  Leaving = 'LEAVING',
  Joining = 'JOINING',
}
