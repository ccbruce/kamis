export enum SshConnectionsSetupMethod {
  Manual = 'MANUAL',
  SemiAutomatic = 'SEMI-AUTOMATIC',
}
