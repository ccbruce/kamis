export enum AlertPolicy {
  Immediately = 'IMMEDIATELY',
  Hourly = 'HOURLY',
  Daily = 'DAILY',
  Never = 'NEVER',
}
