export const nameValidatorRegex = /^[^/ *'"?@!#$%^&()+=~<>;`\\]+$/;
