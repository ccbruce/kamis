export interface SystemFeatures {
  HA: boolean;
  enclosure: boolean;
}
