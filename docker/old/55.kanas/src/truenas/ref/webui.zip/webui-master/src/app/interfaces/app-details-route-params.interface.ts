export interface AppDetailsRouteParams { appId: string; catalog: string; train: string }
