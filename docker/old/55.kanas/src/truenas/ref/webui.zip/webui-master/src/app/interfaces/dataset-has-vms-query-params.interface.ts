export type DatasetHasVmsQueryParams = [
  dataset: string,
  recursive: boolean,
];
