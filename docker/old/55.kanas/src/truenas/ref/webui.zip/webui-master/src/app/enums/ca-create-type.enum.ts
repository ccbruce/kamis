export enum CaCreateType {
  Internal = 'CA_CREATE_INTERNAL',
  Import = 'CA_CREATE_IMPORTED',
  Intermediate = 'CA_CREATE_INTERMEDIATE',
}
