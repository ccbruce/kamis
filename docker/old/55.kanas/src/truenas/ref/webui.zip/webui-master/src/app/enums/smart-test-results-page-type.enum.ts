export enum SmartTestResultPageType {
  Disk = 'disk',
  Pool = 'pool',
}
