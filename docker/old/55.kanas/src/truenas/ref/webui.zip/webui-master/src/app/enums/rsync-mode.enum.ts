export enum RsyncMode {
  Module = 'MODULE',
  Ssh = 'SSH',
}

export enum RsyncSshConnectMode {
  PrivateKey,
  KeyChain,
}
