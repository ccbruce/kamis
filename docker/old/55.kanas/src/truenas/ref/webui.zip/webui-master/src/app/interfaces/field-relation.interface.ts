export interface Relation {
  fieldName: string;
  operatorName: string;
  operatorValue: unknown;
}
