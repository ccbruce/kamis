export enum PoolScanState {
  Scanning = 'SCANNING',
  Finished = 'FINISHED',
  Canceled = 'CANCELED',
}
