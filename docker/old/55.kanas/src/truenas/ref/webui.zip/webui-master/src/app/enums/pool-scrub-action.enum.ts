export enum PoolScrubAction {
  Start = 'START',
  Stop = 'STOP',
  Pause = 'PAUSE',
}
