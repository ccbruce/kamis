export enum FileType {
  Directory = 'DIRECTORY',
  Symlink = 'SYMLINK',
  File = 'FILE',
  Other = 'OTHER',
}
