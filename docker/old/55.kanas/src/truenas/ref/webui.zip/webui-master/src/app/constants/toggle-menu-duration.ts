export const toggleMenuDuration = 400;
