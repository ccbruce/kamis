export enum PoolCardIconType {
  Safe = 'SAFE',
  Warn = 'WARN',
  Faulted = 'FAULTED',
  Error = 'ERROR',
}
