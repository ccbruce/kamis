export interface SmartTestProgressUpdate {
  progress: {
    percent: number;
  };
}
