export type WithInherit<T> = T | typeof inherit;

export const inherit = 'INHERIT' as const;
