export interface LocalizationSettings {
  language: string;
  kbdMap: string;
  timezone: string;
  dateFormat: string;
  timeFormat: string;
}
