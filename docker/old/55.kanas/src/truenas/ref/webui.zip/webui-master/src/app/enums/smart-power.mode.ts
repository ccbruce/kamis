export enum SmartPowerMode {
  Never = 'NEVER',
  Sleep = 'SLEEP',
  Standby = 'STANDBY',
  Idle = 'IDLE',
}
