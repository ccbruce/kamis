export enum ServiceStatus {
  Running = 'RUNNING',
  Stopped = 'STOPPED',
  Loading = 'LOADING', // extra state for UI
}
