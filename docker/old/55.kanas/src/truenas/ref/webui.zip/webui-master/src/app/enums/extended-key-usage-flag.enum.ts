export type ExtendedKeyUsageFlag = string;
