export enum KeychainCredentialType {
  SshKeyPair = 'SSH_KEY_PAIR',
  SshCredentials = 'SSH_CREDENTIALS',
}
