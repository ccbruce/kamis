export enum ZfsSnapshotRetentionSource {
  PeriodicSnapshotTask = 'periodic_snapshot_task',
}
