export const truenasDbKeyLocation = '$TrueNAS';
