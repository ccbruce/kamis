export enum SchemaType {
  String = 'string',
  Null = 'null',
  Boolean = 'boolean',
  Integer = 'integer',
}
