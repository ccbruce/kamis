export enum LogLevel {
  None = 'NONE',
  Minimum = 'MINIMUM',
  Normal = 'NORMAL',
  Full = 'FULL',
  Debug = 'DEBUG',
}
