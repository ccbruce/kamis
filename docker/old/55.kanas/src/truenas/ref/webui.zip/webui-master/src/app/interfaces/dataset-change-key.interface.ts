export interface DatasetChangeKeyParams {
  generate_key?: boolean;
  key_file?: boolean;
  pbkdf2iters?: number;
  passphrase?: string;
  key?: string;
}
