export enum SmartTestResultStatus {
  Success = 'SUCCESS',
  Running = 'RUNNING',
  Aborted = 'ABORTED',
  Failed = 'FAILED',
}
