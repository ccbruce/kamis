export enum AccountAttribute {
  Local = 'LOCAL',
  SysAdmin = 'SYS_ADMIN',
}
