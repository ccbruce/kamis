export enum DiskBus {
  Spi = 'SPI',
  Usb = 'USB',
}
