export enum EmptyType {
  Loading = 'duration',
  FirstUse = 'first_use',
  NoPageData = 'no_page_data',
  Errors = 'errors',
  NoSearchResults = 'no_search_results',
}
