export interface Schedule {
  // TODO: Check question marks
  minute?: string;
  hour?: string;
  dom?: string;
  month?: string;
  dow?: string;

  begin?: string;
  end?: string;
}
