export enum DeviceType {
  Serial = 'SERIAL',
  Disk = 'DISK',
  Gpu = 'GPU',
}
