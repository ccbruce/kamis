export const mntPath = '/mnt';
