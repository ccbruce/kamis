export const officialCatalog = 'TRUENAS';
export const ixChartApp = 'ix-chart';
export const chartsTrain = 'charts';
export const appImagePlaceholder = 'assets/images/truenas_scale_ondark_favicon.png';
export const latestVersion = 'latest';
