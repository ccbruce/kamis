export enum SystemEnvironment {
  Default = 'DEFAULT',
  Ec2 = 'EC2',
}
