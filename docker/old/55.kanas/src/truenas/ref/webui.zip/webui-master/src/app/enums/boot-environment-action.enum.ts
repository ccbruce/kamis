export enum BootEnvironmentAction {
  Create = 'create',
  Rename = 'update',
  Clone = 'clone',
  Delete = 'delete',
}
