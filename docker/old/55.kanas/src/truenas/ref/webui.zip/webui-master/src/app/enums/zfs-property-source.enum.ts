export enum ZfsPropertySource {
  Local = 'LOCAL',
  Default = 'DEFAULT',
  Inherited = 'INHERITED',
  None = 'NONE',
}
