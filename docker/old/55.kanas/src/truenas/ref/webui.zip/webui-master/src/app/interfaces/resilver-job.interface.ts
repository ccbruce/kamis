import { PoolScanUpdate } from 'app/interfaces/pool.interface';

export interface PoolScan {
  name: string;
  scan: PoolScanUpdate;
}
