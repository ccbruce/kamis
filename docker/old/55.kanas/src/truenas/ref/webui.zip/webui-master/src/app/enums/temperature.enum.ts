export enum TemperatureUnit {
  Celsius = 'C',
  Fahrenheit = 'F',
  Kelvin = 'K',
}
