/* eslint-disable @typescript-eslint/naming-convention */
export const kb = 1000;
export const Mb = 1000 ** 2;
export const Gb = 1000 ** 3;
export const Tb = 1000 ** 4;
export const Pb = 1000 ** 5;
