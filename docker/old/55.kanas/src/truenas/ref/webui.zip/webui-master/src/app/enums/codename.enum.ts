export enum Codename {
  ElectricEel = 'ElectricEel',
  Dragonfish = 'Dragonfish',
}
