export type Choices = Record<string, string>;
