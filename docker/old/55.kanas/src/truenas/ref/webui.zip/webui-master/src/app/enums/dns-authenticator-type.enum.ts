export enum DnsAuthenticatorType {
  Route53 = 'route53',
  Cloudflare = 'cloudflare',
}
