export enum SedUser {
  User = 'USER',
  Master = 'MASTER',
}
