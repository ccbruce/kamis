export enum ScreenType {
  Desktop = 'Desktop',
  Mobile = 'Mobile',
}
