export enum NetworkActivityType {
  Allow = 'ALLOW',
  Deny = 'DENY',
}
