export enum ExplorerNodeType {
  Directory = 'directory',
  File = 'file',
}
