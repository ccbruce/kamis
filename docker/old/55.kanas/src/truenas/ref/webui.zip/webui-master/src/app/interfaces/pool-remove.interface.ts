export type PoolRemoveParams = [
  id: number,
  params: {
    label: string | number;
  },
];
