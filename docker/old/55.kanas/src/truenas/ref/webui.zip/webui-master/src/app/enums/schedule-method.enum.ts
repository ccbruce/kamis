export enum ScheduleMethod {
  Cron = 'cron',
  Once = 'once',
}
