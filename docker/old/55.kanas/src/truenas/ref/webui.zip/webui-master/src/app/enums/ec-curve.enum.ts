export type EcCurve = string;
