export enum FileAttribute {
  MountRoot = 'MOUNT_ROOT',
  Immutable = 'IMMUTABLE',
}
