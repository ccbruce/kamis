/* eslint-disable @typescript-eslint/naming-convention */
export const KiB = 1024;
export const MiB = 1024 ** 2;
export const GiB = 1024 ** 3;
export const TiB = 1024 ** 4;
export const PiB = 1024 ** 5;
