export enum SmbSharesecPermission {
  Full = 'FULL',
  Change = 'CHANGE',
  Read = 'READ',
}

export enum SmbSharesecType {
  Allowed = 'ALLOWED',
  Denied = 'DENIED',
}
