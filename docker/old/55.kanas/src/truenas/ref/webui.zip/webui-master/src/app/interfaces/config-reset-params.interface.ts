export interface ConfigResetParams {
  reboot: boolean;
}
