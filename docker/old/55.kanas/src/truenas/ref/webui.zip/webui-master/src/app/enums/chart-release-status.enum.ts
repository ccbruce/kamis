export enum ChartReleaseStatus {
  Active = 'ACTIVE',
  Deploying = 'DEPLOYING',
  Stopped = 'STOPPED',
}
