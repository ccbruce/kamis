export enum MailSecurity {
  Plain = 'PLAIN',
  Ssl = 'SSL',
  Tls = 'TLS',
}
