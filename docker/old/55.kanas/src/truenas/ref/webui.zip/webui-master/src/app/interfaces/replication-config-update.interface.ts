import { ReplicationConfig } from 'app/interfaces/replication-config.interface';

export type ReplicationConfigUpdate = Partial<ReplicationConfig>;
