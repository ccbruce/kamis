export const allCommands = 'ALL';
