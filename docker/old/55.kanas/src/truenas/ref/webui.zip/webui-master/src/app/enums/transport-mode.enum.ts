export enum TransportMode {
  Legacy = 'LEGACY',
  Local = 'LOCAL',
  Ssh = 'SSH',
  Netcat = 'SSH+NETCAT',
}
