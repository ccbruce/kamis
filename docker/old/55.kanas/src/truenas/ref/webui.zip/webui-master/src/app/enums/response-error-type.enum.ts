export enum ResponseErrorType {
  Validation = 'VALIDATION',
}
