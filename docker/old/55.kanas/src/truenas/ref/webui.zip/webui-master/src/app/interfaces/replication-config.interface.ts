export interface ReplicationConfig {
  max_parallel_replication_tasks: number;
}
