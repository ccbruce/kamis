<script>
$('select[name="version"]').parent().remove();
</script>
