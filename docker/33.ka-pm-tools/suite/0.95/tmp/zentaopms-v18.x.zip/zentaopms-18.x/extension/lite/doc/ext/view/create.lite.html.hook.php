<script>
$(function()
{
    $('#submit').parent().append('<input type="hidden" name="vision" id="vision" value="lite">');
});
</script>
