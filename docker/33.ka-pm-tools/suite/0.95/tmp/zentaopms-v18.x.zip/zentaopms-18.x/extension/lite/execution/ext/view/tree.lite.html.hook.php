<script>
$('#mainMenu .dropdown-menu li:last-child').remove();
</script>
