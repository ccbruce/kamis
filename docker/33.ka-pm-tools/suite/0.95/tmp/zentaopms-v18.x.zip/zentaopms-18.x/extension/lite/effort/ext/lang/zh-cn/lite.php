<?php
$lang->effort->objectTypeList = array();
$lang->effort->objectTypeList['custom'] = '';
$lang->effort->objectTypeList['story']  = $lang->SRCommon;
$lang->effort->objectTypeList['task']   = '任务';
$lang->effort->objectTypeList['doc']    = '文档';
$lang->effort->objectTypeList['todo']   = '待办';
