<?php
$lang->company->execution = '看板';
$lang->company->product   = $lang->projectCommon;
