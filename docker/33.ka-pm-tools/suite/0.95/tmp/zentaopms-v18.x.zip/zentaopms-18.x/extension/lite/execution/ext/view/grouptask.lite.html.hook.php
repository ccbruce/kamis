<script>
$('#mainMenu .dropdown-menu #importBug').remove();
</script>
