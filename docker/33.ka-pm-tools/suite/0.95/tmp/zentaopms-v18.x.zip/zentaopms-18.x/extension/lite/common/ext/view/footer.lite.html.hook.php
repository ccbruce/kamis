<script>
$('#userNav li:first ul.dropdown-menu li a[href*="tutorial"]').parent().remove();
$('#userNav li:first ul.dropdown-menu li a[href*="preference"]').parent().remove();
</script>
