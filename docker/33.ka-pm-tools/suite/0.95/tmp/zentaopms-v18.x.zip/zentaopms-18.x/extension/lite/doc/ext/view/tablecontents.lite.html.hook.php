<?php include dirname(__FILE__) . '/objectlibs.lite.html.hook.php';?>
