<?php
$lang->doc->libTypeList = array();
$lang->doc->libTypeList['project'] = "{$lang->projectCommon} Library";
$lang->doc->libTypeList['custom']  = 'Custom Library';
