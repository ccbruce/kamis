<?php
$lang->company->execution = 'Kanban';
$lang->company->product   = $lang->projectCommon;
