<?php
$config->effort->list->exportFields  = 'id,date,dept,account,work,consumed,left,objectType,execution';
$config->effort->list->defaultFields = 'id,date,account,work,consumed,left,objectType,execution';

$config->effort->datatable->defaultField = array('id', 'date', 'account', 'work', 'consumed', 'left', 'objectType', 'execution');
