<?php
$lang->effort->objectTypeList = array();
$lang->effort->objectTypeList['custom'] = '';
$lang->effort->objectTypeList['story']  = $lang->SRCommon;
$lang->effort->objectTypeList['task']   = 'Task';
$lang->effort->objectTypeList['doc']    = 'Doc';
$lang->effort->objectTypeList['todo']   = 'Todo';
