<script>
$(function()
{
    $('#productBox').addClass("hide");
});
</script>
