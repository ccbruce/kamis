<script>
$('#zentaoLinks > .row > .col-sm-2').removeClass('col-sm-2').addClass('col-sm-4');
</script>
