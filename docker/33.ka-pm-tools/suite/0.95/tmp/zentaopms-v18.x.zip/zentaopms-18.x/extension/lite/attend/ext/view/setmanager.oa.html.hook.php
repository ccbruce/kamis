<script>
$(function()
{
    $('#featurebar #settings').addClass('active');
    $('a.setDept').attr('href', createLink('dept', 'browse'));
})
</script>
