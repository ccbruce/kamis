<script>
$('#importActionMenu li:last-child').remove();
</script>
