<?php
$lang->datatable->moduleSetting          = 'Set Module';
$lang->datatable->showModule             = 'Show modules in the list';
$lang->datatable->showAllModule          = 'Show product modules';
$lang->datatable->showModuleList['base'] = 'Base Node';
$lang->datatable->showModuleList['end']  = 'End Node';
