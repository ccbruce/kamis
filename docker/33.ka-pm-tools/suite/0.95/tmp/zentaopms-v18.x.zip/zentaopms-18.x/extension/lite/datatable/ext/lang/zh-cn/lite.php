<?php
$lang->datatable->moduleSetting          = '目录设置';
$lang->datatable->showModule             = '列表页是否显示目录名';
$lang->datatable->showAllModule          = '是否显示完整产品目录';
$lang->datatable->showModuleList['base'] = '只显示一级目录';
$lang->datatable->showModuleList['end']  = '只显示最后一级目录';
