<script>
$(function()
{
    $('#ajaxForm .table #signInClient').closest('tr').hide();
})
</script>
