<script>
$(function()
{
    $('#featurebar #settings').addClass('active');
})
</script>
