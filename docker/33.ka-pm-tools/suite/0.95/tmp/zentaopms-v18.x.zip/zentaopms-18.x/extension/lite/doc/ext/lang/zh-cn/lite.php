<?php
$lang->doc->libTypeList = array();
$lang->doc->libTypeList['project'] = "{$lang->projectCommon}文档库";
$lang->doc->libTypeList['custom']  = '自定义文档库';
