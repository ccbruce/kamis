<script>
$('#itemContent .btn-toolbar a:last-child').remove();
</script>
