<?php
$lang->zdisk = new stdclass();

$lang->zdisk->doing      = '进行中';
$lang->zdisk->wait       = '未开始';
$lang->zdisk->suspend    = '已暂停';
$lang->zdisk->closed     = '已关闭';
$lang->zdisk->openedByMe = '由我创建';
$lang->zdisk->undone     = '未完成';
$lang->zdisk->done       = '已完成';
