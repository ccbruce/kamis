<?php
$lang->zdisk = new stdclass();

$lang->zdisk->doing      = 'Doing';
$lang->zdisk->wait       = 'Wait';
$lang->zdisk->suspend    = 'Suspend';
$lang->zdisk->closed     = 'Closed';
$lang->zdisk->openedByMe = 'OpenedByMe';
$lang->zdisk->undone     = 'Undone';
$lang->zdisk->done       = 'Done';
