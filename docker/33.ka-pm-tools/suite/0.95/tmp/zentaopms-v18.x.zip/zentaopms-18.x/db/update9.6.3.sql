ALTER TABLE `zt_productplan` ADD `order` TEXT  NOT NULL AFTER `end`;
