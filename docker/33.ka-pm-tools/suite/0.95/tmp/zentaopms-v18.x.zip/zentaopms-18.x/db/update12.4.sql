update zt_action set `project` = `extra` where action = 'unlinkedfromproject' and `project` = 0;
