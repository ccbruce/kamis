TRUNCATE TABLE `zt_pivot`;
TRUNCATE TABLE `zt_chart`;
TRUNCATE TABLE `zt_basicmeas`;
DELETE FROM `zt_screen` WHERE id IN (1,2,4,6,7,8);
