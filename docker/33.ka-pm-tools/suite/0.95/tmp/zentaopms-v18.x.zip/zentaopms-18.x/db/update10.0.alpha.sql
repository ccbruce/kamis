ALTER TABLE `zt_userquery` ADD `shortcut` enum('0','1') COLLATE 'utf8_general_ci' NOT NULL DEFAULT '0';
