ALTER TABLE `zt_doclib` ADD `order` tinyint(5) unsigned NOT NULL AFTER `main`;
