-- 2010-04-24 product status field.
UPDATE zt_product SET status='normal';
