UPDATE `zt_workflowlabel` SET `label` = '全部' where `label` = '所有' AND `action` = 'browse';
