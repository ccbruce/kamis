-- pgweb: host="localhost"
-- some comment
-- pgweb: user="foo"

select 'foo'
