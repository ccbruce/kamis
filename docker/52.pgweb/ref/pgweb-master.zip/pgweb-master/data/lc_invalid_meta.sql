-- pgweb: host="localhost" mode="foo"
select 'foo'
