select 'foo'
