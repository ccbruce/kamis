-- pgweb: host="localhost"
select 'foo'
