SELECT
  'n/a' AS data_size,
  'n/a' AS index_size,
  'n/a' AS total_size,
  'n/a' AS rows_count
