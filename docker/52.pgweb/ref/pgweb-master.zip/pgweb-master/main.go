package main

import (
	"github.com/sosedoff/pgweb/pkg/cli"
)

func main() {
	cli.Run()
}
